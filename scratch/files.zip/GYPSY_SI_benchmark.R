# =============================================================================
# GYPSY_SI — Rcpp wrapper and benchmark
# =============================================================================
# Requirements:
#   install.packages(c("Rcpp", "data.table", "microbenchmark"))
#   A working C++ compiler:
#     Windows -> Rtools (https://cran.r-project.org/bin/windows/Rtools/)
#     macOS   -> Xcode Command Line Tools  (`xcode-select --install`)
#     Linux   -> gcc/g++ (usually pre-installed)
# =============================================================================

library(Rcpp)
library(data.table)
library(microbenchmark)

# --- 1. Compile the C++ source ---
#   Place GYPSY_SI_cpp.cpp in your working directory, then:
sourceCpp("GYPSY_SI_cpp.cpp")
#   This compiles once and makes GYPSY_SI_cpp() available in your R session.
#   Recompilation is only needed when the .cpp file changes.

# --- 2. R wrapper (preserves the original interface exactly) ----------------
#   Drop-in replacement for GYPSY_SI_vec(). Passes all arguments through to
#   the compiled C++ function; validation is handled in C++.

GYPSY_SI <- function(spp, topht, age, ndx = 2, iter = 1000, tol = 1e-8) {
  GYPSY_SI_cpp(
    spp   = as.character(spp),
    topht = as.numeric(topht),
    age   = as.numeric(age),
    ndx   = as.integer(ndx),
    iter  = as.integer(iter),
    tol   = as.numeric(tol)
  )
}

# --- 3. Verify outputs match the R version ----------------------------------
#   Run this block once after compiling to confirm numerical equivalence.
#   Tolerance of 1e-6 is well within the convergence tolerance of both versions.

source("GYPSY_SI_vec.R")   # load original R function

test_spp   <- c("AW", "PL", "SW", "SB")
test_topht <- c(15.2, 12.8, 18.4, 10.1)
test_age   <- c(30.0, 25.0, 40.0, 35.0)

r_result   <- GYPSY_SI_vec(test_spp, test_topht, test_age, ndx = 2)
cpp_result <- GYPSY_SI(test_spp, test_topht, test_age, ndx = 2)

cat("R result:   ", round(r_result,   8), "\n")
cat("C++ result: ", round(cpp_result, 8), "\n")
cat("Max diff:   ", max(abs(r_result - cpp_result)), "\n")
stopifnot(all(abs(r_result - cpp_result) < 1e-6))
cat("Outputs match.\n\n")

# --- 4. Benchmark -----------------------------------------------------------
#   Adjust n to reflect a realistic dataset size for your use case.

set.seed(42)
n <- 10000   # <-- change this to your typical row count

spp_pool <- c("AW", "PL", "SW", "SB")
age_min  <- c(AW = 8, PL = 8, SW = 10, SB = 10)

bm_spp   <- sample(spp_pool, n, replace = TRUE)
bm_topht <- runif(n, 5, 30)
bm_age   <- mapply(function(s) runif(1, age_min[s] + 1, 100), bm_spp)

results <- microbenchmark(
  R_version   = GYPSY_SI_vec(bm_spp, bm_topht, bm_age, ndx = 2),
  Cpp_version = GYPSY_SI(bm_spp, bm_topht, bm_age, ndx = 2),
  times = 20L
)

print(results, unit = "ms")
# Reported in milliseconds. Divide by 1000 for seconds.
# The "median" column is the most reliable comparison point.
